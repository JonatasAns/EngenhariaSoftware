package pt.estgp.es.spring;


import org.json.JSONObject;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.util.UriComponentsBuilder;
import pt.estgp.es.spring.domain.Aluno;
import pt.estgp.es.spring.utils.JwtRequest;
import pt.estgp.es.spring.utils.JwtTokenUtil;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class HttpRequestTest {

    @Value(value="${local.server.port}")
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void greetingShouldReturnDefaultMessage() throws Exception {
        assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/api/v1/hello",
                String.class)).contains("Hello world");
    }

    @Autowired
    JwtTokenUtil jwtTokenUtil;

    @Test
    public void testAuthentication() throws Exception
    {
        JwtRequest jwtRequest = new JwtRequest("j@1","123");
        ResponseEntity<String> responseEntityStr  = restTemplate.postForEntity("http://localhost:" + port + "/authenticate",
                jwtRequest, String.class);
        assertThat(responseEntityStr.getStatusCode().value()).isEqualTo(HttpStatus.OK.value());
        System.out.println(responseEntityStr.getBody());
        String token = new JSONObject(responseEntityStr.getBody()).getString("token");
        String usernameFromToken = jwtTokenUtil.getUsernameFromToken(token);
        assertThat(usernameFromToken).isEqualTo("j@1");



        ResponseEntity<Aluno> responseAlunoEntity =
                restTemplate.getForEntity("http://localhost:" + port + "/api/v1/alunos/1",Aluno.class);
        assertThat(responseAlunoEntity.getStatusCode().value()).isEqualTo(HttpStatus.UNAUTHORIZED.value());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer "+token);
        HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);


        responseAlunoEntity =
                 restTemplate.exchange("http://localhost:" + port + "/api/v1/alunos/1",
                         HttpMethod.GET,
                         entity, Aluno.class);


        assertThat(responseAlunoEntity.getStatusCode().value()).isEqualTo(HttpStatus.OK.value());
        assertThat(responseAlunoEntity.getBody()).isNotNull();
        assertThat(responseAlunoEntity.getBody().getId()).isEqualTo(1);
    }
}