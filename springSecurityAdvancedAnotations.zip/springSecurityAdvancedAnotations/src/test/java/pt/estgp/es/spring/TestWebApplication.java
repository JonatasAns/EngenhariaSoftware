package pt.estgp.es.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TestWebApplication {

    @Test
    public void contextLoads() {
        System.out.println("TESTING");
    }

}