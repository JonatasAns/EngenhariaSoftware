package pt.estgp.es.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class IgnoreIT {
    @Test
    public void testFirstLastName()
    {
        boolean dummyTest = 2 < 1;
        System.out.println("Running fail UnityTest");
        assertThat(dummyTest).isEqualTo(true);
    }
}
