package pt.estgp.es.spring.services.exceptions;

public class ServiceException extends Exception{
}
