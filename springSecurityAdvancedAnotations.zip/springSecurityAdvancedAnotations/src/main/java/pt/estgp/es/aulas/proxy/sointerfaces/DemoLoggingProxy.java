package pt.estgp.es.aulas.proxy.sointerfaces;

import java.lang.reflect.*;
import java.io.*;
public class DemoLoggingProxy {
    public static void main(String [] args)
            throws IOException
    {
        ClassLoader cl = DemoLoggingProxy.class.getClassLoader();
        DataOutput dataOutputInterfaceProxy = (DataOutput) Proxy.newProxyInstance(cl, new Class[] {DataOutput.class}, new LoggingHandler());

        dataOutputInterfaceProxy.writeChars("teste");


    }
}

