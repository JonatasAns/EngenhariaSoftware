package pt.estgp.es.aulas.proxy.methodHandler;

import javassist.util.proxy.MethodHandler;
import javassist.util.proxy.ProxyFactory;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Main {
    public static void main(String[] args) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {

        System.out.println("############ Se não o fez coloque estas VM options no edit configurations do Main" +
                "--add-opens java.base/java.lang=ALL-UNNAMED");
        ProxyFactory factory = new ProxyFactory();
        factory.setSuperclass(Pessoa.class);
        factory.setFilter(
                method -> {
                    return true;
                    //return Modifier.isAbstract(method.getModifiers());
                }
        );

        MethodHandler handler = new MethodHandler() {
            @Override
            public Object invoke(Object self, Method thisMethod, Method proceed, Object[] args) throws Throwable {
                System.out.println("Handling " + thisMethod + " via the method handler");
                if(thisMethod.getName().startsWith("getId"))
                {
                    return proceed.invoke(self,args);
                }
                else if(thisMethod.getName().startsWith("get"))
                {
                    System.out.println("Acedendo a uma propriedade " + thisMethod.getName() + " na class " + thisMethod.getDeclaringClass().getName());
                    String campo  = thisMethod.getName().substring(3);
                    campo = ("" + campo.charAt(0)).toLowerCase() + campo.substring(1);
                    System.out.println("select " + campo + " from " + thisMethod.getDeclaringClass().getCanonicalName() + " where id = " +
                            self.getClass().getMethod("getId").invoke(self, new Object[]{}));
                }
                if(thisMethod.getName().startsWith("set"))
                {
                    System.out.println("Alterando uma propriedade no proxy " + thisMethod.getName() + " na class " + thisMethod.getDeclaringClass().getName());
                    return proceed.invoke(self,args);
                }
                return null;
            }
        };


        Pessoa u = (Pessoa) factory.create(new Class[0], new Object[0], handler);
        u.setId(3);

        u.getNome();

        u.getId();


        Pessoa u2 = (Pessoa) factory.create(new Class[0], new Object[0], new DomainMethodHandler());
        u2.setId(3);

        u2.getNome();

        u2.getId();

    }
}
