package pt.estgp.es.spring.services.security;

import pt.estgp.es.spring.domain.Aluno;

public class AlunoWrapper {
    Aluno aluno;

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }
}
