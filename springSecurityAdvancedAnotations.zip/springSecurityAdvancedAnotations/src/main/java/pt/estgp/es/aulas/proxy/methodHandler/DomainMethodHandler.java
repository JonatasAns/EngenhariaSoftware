package pt.estgp.es.aulas.proxy.methodHandler;

import javassist.util.proxy.MethodHandler;

import java.lang.reflect.Method;

public class DomainMethodHandler implements MethodHandler
{
    @Override
    public Object invoke(Object self, Method thisMethod, Method proceed, Object[] args) throws Throwable
    {
        System.out.println("Handling " + thisMethod + " via the method handler");
        if(thisMethod.getName().startsWith("getId"))
        {
            return proceed.invoke(self,args);
        }
        else if(thisMethod.getName().startsWith("get"))
        {
            System.out.println("Acedendo a uma propriedade " + thisMethod.getName() + " na class " + thisMethod.getDeclaringClass().getName());
            String campo  = thisMethod.getName().substring(3);
            campo = ("" + campo.charAt(0)).toLowerCase() + campo.substring(1);
            System.out.println("select " + campo + " from " + thisMethod.getDeclaringClass().getCanonicalName() + " where id = " +
                    self.getClass().getMethod("getId").invoke(self, new Object[]{}));
        }
        if(thisMethod.getName().startsWith("set"))
        {
            System.out.println("Alterando uma propriedade no proxy " + thisMethod.getName() + " na class " + thisMethod.getDeclaringClass().getName());
            return proceed.invoke(self,args);
        }
        return null;
    }
};

