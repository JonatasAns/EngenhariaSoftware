package pt.estgp.es.spring.services.exceptions;

public class EntityNotFoundException  extends ServiceException{
}
