package pt.estgp.es.spring.services.security;

public @interface CustomSecurityAnnotation {
}
