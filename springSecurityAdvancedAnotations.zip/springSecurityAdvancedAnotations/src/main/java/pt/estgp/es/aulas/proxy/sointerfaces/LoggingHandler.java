package pt.estgp.es.aulas.proxy.sointerfaces;

import java.lang.reflect.*;
public class LoggingHandler implements InvocationHandler
{
    public Object invoke(Object self, Method method,
                         Object[] args) throws Throwable
    {
        System.out.println("Handling " + method + " via the method handler");
        if (method.getName().startsWith("getId")) {
            return method.invoke(self, args);
        } else if (method.getName().startsWith("get")) {
            System.out.println("Acedendo a uma propriedade " + method.getName() + " na class " + method.getDeclaringClass().getName());
            String campo = method.getName().substring(3);
            campo = ("" + campo.charAt(0)).toLowerCase() + campo.substring(1);
            System.out.println("select " + campo + " from " + method.getDeclaringClass().getCanonicalName() + " where id = " +
                    self.getClass().getMethod("getId").invoke(self, new Object[]{}));
        }
        if (method.getName().startsWith("set")) {
            System.out.println("Alterando uma propriedade no proxy " + method.getName() + " na class " + method.getDeclaringClass().getName());
            return method.invoke(self, args);
        }
        return null;
    }

}
